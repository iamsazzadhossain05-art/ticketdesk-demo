<?php
declare(strict_types=1);
$config = require dirname(__DIR__).'/config.php';
const APP_VERSION = '1.1.0';
const SCHEMA_VERSION = 2;
const STATUSES = ['Open','In Progress','Pending','Resolved','Closed'];
const DONE_STATUSES = ['Resolved','Closed'];
function cfg(string $key, mixed $default=null): mixed { global $config; return $config[$key] ?? $default; }
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name('ticketdesk_session');
    session_set_cookie_params(['lifetime'=>0,'path'=>'/','secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off','httponly'=>true,'samesite'=>'Lax']);
    session_start();
}
$idle=(int)cfg('idle_timeout_minutes',120)*60;
if(!empty($_SESSION['uid']) && $idle>0 && time()-(int)($_SESSION['seen']??time())>$idle){ $_SESSION=[]; }
if(!str_starts_with((string)($_SERVER['REQUEST_URI']??''),'/api/')) $_SESSION['seen']=time();
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('Content-Security-Policy: default-src \'self\'; style-src \'self\' \'unsafe-inline\'; script-src \'self\'; img-src \'self\' data:; font-src \'self\'; object-src \'none\'; base-uri \'self\'; frame-ancestors \'none\'');
date_default_timezone_set($config['timezone'] ?? 'Asia/Dhaka');
function db(): PDO {
    static $pdo;
    global $config;
    if ($pdo) return $pdo;
    $dir = dirname($config['db_path']);
    if (!is_dir($dir)) mkdir($dir, 0700, true);
    $pdo = new PDO('sqlite:'.$config['db_path'], null, null, [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC]);
    $pdo->exec('PRAGMA foreign_keys=ON');
    $pdo->exec('PRAGMA busy_timeout=5000');
    $pdo->exec('PRAGMA journal_mode=WAL');
    return $pdo;
}
function one(string $sql,array $params=[]): ?array { $s=db()->prepare($sql); $s->execute($params); return $s->fetch() ?: null; }
function all(string $sql,array $params=[]): array { $s=db()->prepare($sql); $s->execute($params); return $s->fetchAll(); }
function run(string $sql,array $params=[]): int { $s=db()->prepare($sql); $s->execute($params); return $s->rowCount(); }
function h(mixed $x): string { return htmlspecialchars((string)($x ?? ''),ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8'); }
function u(string $path): string { return $path; }
function go(string $path): never { header('Location: '.$path, true, 303); exit; }
function flash(string $message,string $type='success'): void { $_SESSION['flash'][]=['message'=>$message,'type'=>$type]; }
function csrf(): string { if (empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function token(): string { return '<input type="hidden" name="csrf" value="'.h(csrf()).'">'; }
function check_csrf(): void { if (!hash_equals(csrf(),(string)($_POST['csrf']??''))) fail(419,'Security token expired. Reload the page and retry.'); }
function fail(int $code,string $msg): never { http_response_code($code); echo '<!doctype html><meta charset="utf-8"><title>Error</title><body style="font:16px system-ui;padding:48px"><h2>'.h($code).'</h2><p>'.h($msg).'</p><a href="/">Go back</a></body>'; exit; }
function user(): ?array { if (empty($_SESSION['uid'])) return null; $u=one('SELECT id,name,email,role,department_id,active FROM users WHERE id=?',[(int)$_SESSION['uid']]); return $u && $u['active'] ? $u : null; }
function need_login(): array { $u=user(); if (!$u) go('/login'); return $u; }
function admin(array $u): void { if ($u['role']!=='admin') fail(403,'Admin permissions required.'); }
function is_admin(array $u): bool { return $u['role']==='admin'; }
function is_overdue(array $t): bool { return !empty($t['due_date']) && $t['due_date']<date('Y-m-d') && !in_array($t['status'],DONE_STATUSES,true); }
function json_out(array $data,int $code=200): never { http_response_code($code); header('Content-Type: application/json; charset=utf-8'); header('Cache-Control: no-store'); echo json_encode($data,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE); exit; }
/** Admin-managed lookup lists (brand, source, priority) live in the options table. */
function options(string $type,bool $activeOnly=true): array { static $cache=[]; $k=$type.($activeOnly?'1':'0'); return $cache[$k]??=all('SELECT * FROM options WHERE type=?'.($activeOnly?' AND active=1':'').' ORDER BY sort_order,id',[$type]); }
function option_names(string $type,bool $activeOnly=true): array { return array_column(options($type,$activeOnly),'name'); }
/** name=>name map for <select>, optionally keeping a record's current (possibly disabled) value selectable. */
function option_map(string $type,?string $keep=null): array { $n=option_names($type); if($keep!==null && $keep!=='' && !in_array($keep,$n,true)) $n[]=$keep; return array_combine($n,$n); }
function valid_choice(string $type,string $value,string $label,?string $current=null): string { if($current!==null && $value===$current) return $value; if(!in_array($value,option_names($type),true)) fail(422,'Invalid '.$label); return $value; }
function sla_due(string $priority): ?string { $h=(int)(one('SELECT sla_hours FROM options WHERE type=? AND name=?',['priority',$priority])['sla_hours']??0); return $h>0?date('Y-m-d',time()+$h*3600):null; }
function role_name(string $r): string { return ['admin'=>'Administrator','agent'=>'Customer Service','resolver'=>'Issue Resolution'][$r]??$r; }
function permitted(array $u,array $ticket): bool { return is_admin($u) || ($u['role']==='agent' && (int)$ticket['created_by']===(int)$u['id']) || ($u['role']==='resolver' && ((int)$ticket['assignee_id']===(int)$u['id'] || (int)$ticket['department_id']===(int)$u['department_id'] && $u['department_id']!==null)); }
function ticket_access(array $u,int $id): array { $t=one('SELECT t.*, c.name customer_name,c.phone customer_phone, cb.name creator_name,ab.name assignee_name,d.name department_name,ct.name category_name FROM tickets t JOIN customers c ON c.id=t.customer_id JOIN users cb ON cb.id=t.created_by LEFT JOIN users ab ON ab.id=t.assignee_id LEFT JOIN departments d ON d.id=t.department_id LEFT JOIN categories ct ON ct.id=t.category_id WHERE t.id=?',[$id]); if (!$t) fail(404,'Ticket not found.'); if (!permitted($u,$t)) fail(403,'This ticket is not assigned or visible to you.'); return $t; }
function audit(int $ticketId,int $actorId,string $action,string $details=''): void { run('INSERT INTO activities(ticket_id,user_id,action,details,created_at) VALUES(?,?,?,?,?)',[$ticketId,$actorId,$action,$details,date('Y-m-d H:i:s')]); }
function active_staff(string $role=''): array { return all('SELECT u.id,u.name,u.role,u.department_id,d.name department FROM users u LEFT JOIN departments d ON d.id=u.department_id WHERE u.active=1 '.($role?'AND u.role=? ':'').'ORDER BY u.name', $role?[$role]:[]); }
function field(string $key,int $max=1000): string { return trim(mb_substr((string)($_POST[$key]??''),0,$max)); }
function number_field(string $key): ?int { $s=field($key,12); return $s!=='' && ctype_digit($s)?(int)$s:null; }
function valid_option(string $value,array $allowed,string $label): string { if (!in_array($value,$allowed,true)) fail(422,'Invalid '.$label); return $value; }
function schema(): void {
    // Cheap fast-path: after the first request this is a single PRAGMA read instead of ~12 DDL statements.
    if((int)db()->query('PRAGMA user_version')->fetchColumn()>=SCHEMA_VERSION) return;
    db()->beginTransaction();
    try {
        if((int)db()->query('PRAGMA user_version')->fetchColumn()>=SCHEMA_VERSION){ db()->rollBack(); return; } // another request migrated first
        db()->exec(<<<'SQL'
CREATE TABLE IF NOT EXISTS departments(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE);
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,email TEXT NOT NULL UNIQUE,password_hash TEXT NOT NULL,role TEXT NOT NULL CHECK(role IN ('admin','agent','resolver')),department_id INTEGER REFERENCES departments(id),active INTEGER NOT NULL DEFAULT 1,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL,phone TEXT NOT NULL UNIQUE,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS categories(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE,active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS tickets(id INTEGER PRIMARY KEY AUTOINCREMENT,code TEXT UNIQUE,customer_id INTEGER NOT NULL REFERENCES customers(id),created_by INTEGER NOT NULL REFERENCES users(id),assignee_id INTEGER REFERENCES users(id),department_id INTEGER REFERENCES departments(id),category_id INTEGER REFERENCES categories(id),brand TEXT NOT NULL DEFAULT 'LottoBD',source TEXT NOT NULL DEFAULT 'Phone',order_id TEXT,product_sku TEXT,subject TEXT NOT NULL,description TEXT NOT NULL,priority TEXT NOT NULL DEFAULT 'Medium',status TEXT NOT NULL DEFAULT 'Open',due_date TEXT,followup_date TEXT,resolution TEXT,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,closed_at TEXT);
CREATE TABLE IF NOT EXISTS activities(id INTEGER PRIMARY KEY AUTOINCREMENT,ticket_id INTEGER NOT NULL REFERENCES tickets(id),user_id INTEGER NOT NULL REFERENCES users(id),action TEXT NOT NULL,details TEXT,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS attachments(id INTEGER PRIMARY KEY AUTOINCREMENT,ticket_id INTEGER NOT NULL REFERENCES tickets(id),user_id INTEGER NOT NULL REFERENCES users(id),original_name TEXT NOT NULL,stored_name TEXT NOT NULL,mime TEXT NOT NULL,size INTEGER NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS options(id INTEGER PRIMARY KEY AUTOINCREMENT,type TEXT NOT NULL,name TEXT NOT NULL,sort_order INTEGER NOT NULL DEFAULT 0,sla_hours INTEGER NOT NULL DEFAULT 0,active INTEGER NOT NULL DEFAULT 1,UNIQUE(type,name));
CREATE INDEX IF NOT EXISTS idx_tickets_customer ON tickets(customer_id);
CREATE INDEX IF NOT EXISTS idx_tickets_assignee ON tickets(assignee_id);
CREATE INDEX IF NOT EXISTS idx_tickets_created ON tickets(created_at);
CREATE INDEX IF NOT EXISTS idx_activities_ticket ON activities(ticket_id,created_at);
CREATE INDEX IF NOT EXISTS idx_tickets_status ON tickets(status);
CREATE INDEX IF NOT EXISTS idx_tickets_due ON tickets(due_date);
CREATE INDEX IF NOT EXISTS idx_tickets_dept ON tickets(department_id);
SQL);
        // v2 migrations (safe to re-run on existing v1 installs; no data is touched)
        if(!in_array('active',array_column(all('PRAGMA table_info(departments)'),'name'),true)) db()->exec('ALTER TABLE departments ADD COLUMN active INTEGER NOT NULL DEFAULT 1');
        seed_options();
        db()->exec('PRAGMA user_version='.SCHEMA_VERSION);
        db()->commit();
    } catch(Throwable $e){ if(db()->inTransaction()) db()->rollBack(); throw $e; }
}
function seed_options(): void {
    $defaults=['brand'=>[['LottoBD'],['LeeCooperBD'],['Other']],
        'source'=>[['Phone'],['Facebook'],['WhatsApp'],['Email'],['Website'],['Outlet'],['Other']],
        'priority'=>[['Low',72],['Medium',48],['High',24],['Urgent',8]]]; // [name, default SLA hours]
    foreach($defaults as $type=>$rows){ $i=0; foreach($rows as $r){ $i+=10; run('INSERT OR IGNORE INTO options(type,name,sort_order,sla_hours) VALUES(?,?,?,?)',[$type,$r[0],$i,$r[1]??0]); } }
}
function install_defaults(): void {
    foreach (['Customer Service','Operations / Delivery','Warehouse','Accounts','Product / QC','Outlet Team','IT'] as $n) run('INSERT OR IGNORE INTO departments(name) VALUES(?)',[$n]);
    foreach (['Delivery Issue','Wrong / Missing Product','Product Quality','Exchange / Return','Payment / Refund','Order Modification','Outlet Complaint','Website Issue','Other'] as $n) run('INSERT OR IGNORE INTO categories(name) VALUES(?)',[$n]);
}
