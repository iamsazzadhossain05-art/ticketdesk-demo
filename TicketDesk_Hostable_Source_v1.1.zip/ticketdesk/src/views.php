<?php
require_once __DIR__.'/bootstrap.php';
function layout(string $title,string $body,?array $u=null): void {
    $flashes=$_SESSION['flash']??[];unset($_SESSION['flash']);
    $path=parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH)?:'/';
    $head='<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'.h($title).' | '.h(cfg('app_name','TicketDesk')).'</title><link rel="stylesheet" href="/assets/style.css?v='.asset_v('style.css').'"><script src="/assets/app.js?v='.asset_v('app.js').'" defer></script></head><body data-refresh="'.(int)cfg('refresh_seconds',30).'">';
    echo $head;
    if (!$u) { echo '<div class="login-shell"><div class="login-card"><div class="logo">'.logo_html().'</div><p class="muted">Customer Complaint Management</p>'; foreach($flashes as $f) echo '<div class="flash '.h($f['type']).'">'.h($f['message']).'</div>'; echo $body.'</div></div></body></html>'; return; }
    $links=['/'=>'▦ Dashboard','/tickets'=>'◫ Tickets','/tickets/new'=>'＋ New Ticket','/customers'=>'♙ Customers','/reports'=>'▥ Reports'];
    if ($u['role']==='admin') { $links['/users']='♧ Team Management'; $links['/settings']='⚙ Settings'; }
    echo '<div class="layout"><aside class="sidebar"><div class="brand">'.logo_html().'</div><nav class="nav">';
    foreach($links as $url=>$label) { if($u['role']==='resolver' && ($url==='/tickets/new'||$url==='/customers')) continue; $active=($path===$url || ($url==='/tickets' && preg_match('#^/tickets/\d+$#',$path)))?' active':''; echo '<a class="'.$active.'" href="'.h($url).'">'.h($label).'</a>'; }
    echo '</nav><div class="sidebar-foot">Internal Complaint Management<br>Version '.h(APP_VERSION).'</div></aside><div class="main"><header class="topbar"><div><strong>'.h($title).'</strong></div><div class="actions"><span class="muted small">'.h($u['name']).' · '.h(role_name($u['role'])).'</span><form method="post" action="/logout">'.token().'<button class="btn secondary small">Log out</button></form></div></header><main class="content">';
    foreach($flashes as $f) echo '<div class="flash '.h($f['type']).'">'.h($f['message']).'</div>';
    echo $body.'</main><div class="footer">'.h(cfg('app_name','TicketDesk')).' · Secure internal ticket management</div></div></div></body></html>';
}
function asset_v(string $f): int { return (int)@filemtime(dirname(__DIR__).'/public/assets/'.$f); }
function logo_html(): string { $n=(string)cfg('app_name','TicketDesk'); return preg_match('/^(.*?)([A-Z][a-z]*)$/u',$n,$m)&&$m[1]!==''?h($m[1]).'<span>'.h($m[2]).'</span>':h($n); }
function capture(callable $fn): string {ob_start(); $fn(); return ob_get_clean();}
function titlebar(string $t,string $desc='',string $action=''): void {echo '<div class="row"><div><h1 class="page-title">'.h($t).'</h1><p class="sub">'.h($desc).'</p></div>'.$action.'</div>';}
function select_html(string $name,array $values,mixed $selected=null,string $blank='',array $optAttrs=[]): string {
    $out='<select name="'.h($name).'">';if($blank!=='')$out.='<option value="">'.h($blank).'</option>';
    foreach($values as $k=>$val){$at='';foreach($optAttrs[$k]??[] as $an=>$av)$at.=' '.h($an).'="'.h($av).'"';$out.='<option value="'.h($k).'"'.$at.((string)$selected===(string)$k?' selected':'').'>'.h($val).'</option>';}
    return $out.'</select>';
}
function input_field(string $name,string $label,string $value='',string $type='text',bool $required=false,string $hint=''): void {echo '<div class="field"><label for="'.h($name).'">'.h($label).($required?' *':'').'</label><input class="input" id="'.h($name).'" name="'.h($name).'" type="'.h($type).'" value="'.h($value).'" '.($required?'required':'').' '.($type==='date'?'':'maxlength="200"').' placeholder="'.h($hint).'"></div>';}
function statebadge(string $s): string {return '<span class="badge '.h(str_replace(' ','-',$s)).'">'.h($s).'</span>';}
function ticket_table(array $tickets): void {
    if (!$tickets) {echo '<div class="empty">No tickets found for this view.</div>';return;}
    echo '<div class="table-wrap"><table><thead><tr><th>Ticket</th><th>Customer / Order</th><th>Complaint</th><th>Assigned to</th><th>Priority</th><th>Status</th><th>Created</th></tr></thead><tbody>';
    foreach($tickets as $t) echo '<tr><td><a href="/tickets/'.(int)$t['id'].'"><strong>'.h($t['code']).'</strong></a></td><td>'.h($t['customer_name']).'<br><span class="muted small">'.h($t['order_id']?:$t['customer_phone']).'</span></td><td>'.h($t['subject']).'<br><span class="muted small">'.h($t['category_name']??'Uncategorized').'</span></td><td>'.h($t['assignee_name']??'Unassigned').'</td><td>'.statebadge($t['priority']).'</td><td>'.statebadge($t['status']).(is_overdue($t)?'<br><span style="color:#b42318;font-size:11px">Overdue</span>':'').'</td><td>'.h(substr($t['created_at'],0,16)).'</td></tr>';
    echo '</tbody></table></div>';
}
const TICKET_FROM=' FROM tickets t JOIN customers c ON c.id=t.customer_id LEFT JOIN users a ON a.id=t.assignee_id LEFT JOIN categories cat ON cat.id=t.category_id ';
/** Row-level visibility rule, shared by lists, counts, stats and lookups so they can never disagree. */
function ticket_scope(array $u): array {
    if($u['role']==='agent') return ['t.created_by=?',[$u['id']]];
    if($u['role']==='resolver') return ['(t.assignee_id=? OR (t.department_id=? AND ? IS NOT NULL))',[$u['id'],$u['department_id'],$u['department_id']]];
    return ['',[]];
}
function ticket_query(array $u,string $where='',array $params=[],int $limit=500,int $offset=0): array {
    [$scope,$sp]=ticket_scope($u);$conditions=array_filter([$scope,$where]);
    $sql='SELECT t.*,c.name customer_name,c.phone customer_phone,a.name assignee_name,cat.name category_name'.TICKET_FROM.($conditions?'WHERE '.implode(' AND ',$conditions):'').' ORDER BY t.created_at DESC,t.id DESC LIMIT '.(int)$limit.' OFFSET '.max(0,$offset);
    return all($sql,array_merge($sp,$params));
}
function ticket_total(array $u,string $where='',array $params=[]): int {
    [$scope,$sp]=ticket_scope($u);$conditions=array_filter([$scope,$where]);
    return (int)one('SELECT COUNT(*) n'.TICKET_FROM.($conditions?'WHERE '.implode(' AND ',$conditions):''),array_merge($sp,$params))['n'];
}
/** Aggregates in SQL (one query) instead of hydrating thousands of rows in PHP. */
function dashboard_stats(array $u): array {
    [$scope,$sp]=ticket_scope($u);$today=date('Y-m-d');$open="t.status NOT IN ('Resolved','Closed')";$w=$scope?' WHERE '.$scope:'';
    $r=one("SELECT COUNT(*) total,SUM(t.status='Open') open_c,SUM(t.status='In Progress') in_progress,SUM(t.status='Pending') pending,SUM(t.status='Resolved') resolved,SUM(t.due_date IS NOT NULL AND t.due_date<? AND $open) overdue,SUM(t.due_date=? AND $open) due_today,SUM(t.assignee_id IS NULL AND $open) unassigned FROM tickets t".$w,array_merge([$today,$today],$sp))??[];
    $prio=[];foreach(all("SELECT t.priority,COUNT(*) n FROM tickets t WHERE $open".($scope?" AND $scope":'')." GROUP BY t.priority",$sp) as $x)$prio[$x['priority']]=(int)$x['n'];
    return ['total'=>(int)($r['total']??0),'open'=>(int)($r['open_c']??0),'in_progress'=>(int)($r['in_progress']??0),'pending'=>(int)($r['pending']??0),'resolved'=>(int)($r['resolved']??0),'overdue'=>(int)($r['overdue']??0),'due_today'=>(int)($r['due_today']??0),'unassigned'=>(int)($r['unassigned']??0),'by_priority'=>$prio,'updated'=>date('H:i:s')];
}
function filters(array $u,bool $report=false): array {
    $w=[];$p=[];$q=trim((string)($_GET['q']??''));$status=(string)($_GET['status']??'');$brand=(string)($_GET['brand']??'');$prio=(string)($_GET['priority']??'');$from=(string)($_GET['from']??'');$to=(string)($_GET['to']??'');
    $openSql="t.status NOT IN ('Resolved','Closed')";
    if($q!==''){ $w[]='(t.code LIKE ? OR t.subject LIKE ? OR c.name LIKE ? OR c.phone LIKE ? OR t.order_id LIKE ?)';for($i=0;$i<5;$i++)$p[]='%'.$q.'%';}
    if(in_array($status,STATUSES,true)){$w[]='t.status=?';$p[]=$status;}
    if(in_array($brand,option_names('brand',false),true)){$w[]='t.brand=?';$p[]=$brand;}
    if(in_array($prio,option_names('priority',false),true)){$w[]='t.priority=?';$p[]=$prio;}
    if(($_GET['overdue']??'')==='1'){$w[]="t.due_date IS NOT NULL AND t.due_date<? AND $openSql";$p[]=date('Y-m-d');}
    if(($_GET['due']??'')==='today'){$w[]="t.due_date=? AND $openSql";$p[]=date('Y-m-d');}
    $as=(string)($_GET['assignee']??'');
    if($as==='none'){$w[]="t.assignee_id IS NULL AND $openSql";}elseif($as==='me'){$w[]='t.assignee_id=?';$p[]=$u['id'];}
    if(preg_match('/^\d{4}-\d{2}-\d{2}$/',$from)){$w[]='date(t.created_at)>=?';$p[]=$from;}
    if(preg_match('/^\d{4}-\d{2}-\d{2}$/',$to)){$w[]='date(t.created_at)<=?';$p[]=$to;}
    return [$w?'('.implode(') AND (',$w).')':'',$p];
}
function filter_form(string $action,bool $live=false): void {
    $chips=['overdue'=>['1'=>'Overdue only'],'due'=>['today'=>'Due today'],'assignee'=>['none'=>'Unassigned','me'=>'Assigned to me']];$hidden='';$chipHtml='';
    foreach($chips as $k=>$vals){$v=(string)($_GET[$k]??'');if(isset($vals[$v])){$hidden.='<input type="hidden" name="'.h($k).'" value="'.h($v).'">';$chipHtml.='<span class="pill">'.h($vals[$v]).'</span> ';}}
    $opt=fn(string $t)=>array_combine(option_names($t,false),option_names($t,false));
    echo '<form method="get" action="'.h($action).'" class="card filterbar"'.($live?' data-live':' data-autosubmit').'>'.$hidden.'<div class="field wide"><label>Search</label><input class="input" name="q" placeholder="ID, phone, name, order..." value="'.h($_GET['q']??'').'"></div><div class="field"><label>Status</label>'.select_html('status',array_combine(STATUSES,STATUSES),$_GET['status']??null,'All statuses').'</div><div class="field"><label>Brand</label>'.select_html('brand',$opt('brand'),$_GET['brand']??null,'All brands').'</div><div class="field"><label>Priority</label>'.select_html('priority',$opt('priority'),$_GET['priority']??null,'All priorities').'</div><div class="field"><label>From date</label><input class="input" type="date" name="from" value="'.h($_GET['from']??'').'"></div><div class="field"><label>To date</label><input class="input" type="date" name="to" value="'.h($_GET['to']??'').'"></div><button class="btn">Filter</button><a class="btn secondary" data-clear href="'.h($action).'">Clear</a>'.($chipHtml?'<div class="chips">'.$chipHtml.'</div>':'').'</form>';
}
function pagination(int $total,int $page,int $size,string $base): string {
    $pages=max(1,(int)ceil($total/$size));if($pages<2)return '';
    $q=$_GET;unset($q['page'],$q['partial']);
    $link=fn(int $p,string $label,bool $cur=false)=>'<a data-page class="btn small'.($cur?'':' secondary').'" href="'.h($base.'?'.http_build_query($q+['page'=>$p])).'">'.h($label).'</a>';
    $out='<div class="pager">';if($page>1)$out.=$link($page-1,'‹ Prev');
    for($i=max(1,$page-2);$i<=min($pages,$page+2);$i++)$out.=$link($i,(string)$i,$i===$page);
    if($page<$pages)$out.=$link($page+1,'Next ›');
    return $out.'</div>';
}
