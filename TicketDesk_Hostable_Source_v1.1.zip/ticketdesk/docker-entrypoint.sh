#!/bin/sh
# Derive PHP limits from the same env var the app reads, so the two can never disagree.
# (Stock php:apache ships upload_max_filesize=2M, which silently broke the advertised 5 MB attachments.)
set -e
MB="${TICKETDESK_MAX_UPLOAD_MB:-5}"
case "$MB" in ''|*[!0-9]*) MB=5 ;; esac
cat > /usr/local/etc/php/conf.d/zz-ticketdesk.ini <<INI
upload_max_filesize=$((MB + 1))M
post_max_size=$((MB + 3))M
expose_php=0
session.use_strict_mode=1
INI
exec apache2-foreground
