<?php
// This file must remain OUTSIDE the web-accessible public/ directory.
// Every value can be overridden with an environment variable, so one codebase
// can serve several deployments without code edits.
$env = static function (string $key, mixed $default = null): mixed {
    $v = getenv($key);
    return ($v === false || $v === '') ? $default : $v;
};
$int = static fn (string $key, int $default, int $min, int $max): int =>
    max($min, min($max, (int)$env($key, $default)));

return [
    'app_name'             => (string)$env('TICKETDESK_APP_NAME', 'TicketDesk'),
    'db_path'              => (string)$env('TICKETDESK_DB_PATH', __DIR__.'/storage/tickets.sqlite'),
    'upload_path'          => (string)$env('TICKETDESK_UPLOAD_PATH', __DIR__.'/storage/uploads'),
    'timezone'             => (string)$env('TICKETDESK_TIMEZONE', 'Asia/Dhaka'),
    'max_upload_bytes'     => $int('TICKETDESK_MAX_UPLOAD_MB', 5, 1, 50) * 1024 * 1024,
    'page_size'            => $int('TICKETDESK_PAGE_SIZE', 25, 5, 200),
    'refresh_seconds'      => $int('TICKETDESK_REFRESH_SECONDS', 30, 10, 600),
    'idle_timeout_minutes' => $int('TICKETDESK_IDLE_MINUTES', 120, 0, 1440), // 0 = never
];
