/* TicketDesk progressive enhancement. Every page still works without JavaScript;
   this file only adds live behaviour. No inline scripts (CSP: script-src 'self'). */
(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };

  function toast(msg) {
    let wrap = $('.toast-wrap');
    if (!wrap) { wrap = document.createElement('div'); wrap.className = 'toast-wrap'; wrap.setAttribute('role', 'status'); document.body.append(wrap); }
    const t = document.createElement('div'); t.className = 'toast'; t.textContent = msg; wrap.append(t);
    setTimeout(() => t.remove(), 5000);
  }

  async function getJSON(url) {
    const r = await fetch(url, { credentials: 'same-origin', headers: { Accept: 'application/json' } });
    if (r.status === 401) { location.href = '/login'; return null; }
    if (!r.ok) throw new Error('HTTP ' + r.status);
    return r.json();
  }

  /* 1. Live ticket list: search-as-you-type, instant filters, in-place pagination. */
  const live = $('form[data-live]'), box = $('#results');
  if (live && box) {
    let ctl;
    const load = async (url) => {
      ctl?.abort(); ctl = new AbortController(); box.classList.add('loading');
      try {
        const u = new URL(url, location.href); u.searchParams.set('partial', '1');
        const r = await fetch(u, { credentials: 'same-origin', signal: ctl.signal });
        if (r.redirected && new URL(r.url).pathname === '/login') { location.href = '/login'; return; }
        if (!r.ok) throw new Error('HTTP ' + r.status);
        box.innerHTML = await r.text();
        u.searchParams.delete('partial'); history.replaceState(null, '', u.pathname + u.search);
      } catch (e) { if (e.name !== 'AbortError') toast('Could not refresh the list. Check your connection.'); }
      finally { box.classList.remove('loading'); }
    };
    const run = () => {
      const p = new URLSearchParams(new FormData(live));
      for (const [k, v] of [...p]) if (v === '') p.delete(k);
      load('/tickets' + (p.toString() ? '?' + p : ''));
    };
    live.addEventListener('submit', e => { e.preventDefault(); run(); });
    live.addEventListener('input', debounce(e => { if (e.target.matches('input[name=q]')) run(); }, 350));
    live.addEventListener('change', e => { if (e.target.matches('select,input[type=date]')) run(); });
    live.addEventListener('click', e => {
      const clear = e.target.closest('a[data-clear]'); if (!clear) return;
      e.preventDefault(); $$('input[type=hidden]', live).forEach(i => i.remove()); $$('.chips', live).forEach(c => c.remove());
      $$('input:not([type=hidden]),select', live).forEach(i => { i.value = ''; }); run();
    });
    box.addEventListener('click', e => { const a = e.target.closest('a[data-page]'); if (a) { e.preventDefault(); load(a.href); window.scrollTo({ top: 0, behavior: 'smooth' }); } });
  }
  // Non-live filter forms (reports): apply as soon as a dropdown or date changes.
  $$('form[data-autosubmit]').forEach(f => f.addEventListener('change', e => { if (e.target.matches('select,input[type=date]')) f.requestSubmit(); }));

  /* 2. Dashboard: poll lightweight stats, pause when the tab is hidden. */
  const dash = $('#dash');
  if (dash) {
    const secs = Math.max(10, +document.body.dataset.refresh || 30);
    let prev = +dash.dataset.total || 0;
    const apply = d => {
      $$('[data-stat]').forEach(el => { if (d[el.dataset.stat] !== undefined) el.textContent = d[el.dataset.stat]; });
      $('[data-stat-card=overdue]')?.classList.toggle('alert', d.overdue > 0);
      const max = Math.max(1, ...Object.values(d.by_priority));
      $$('[data-prio]').forEach(el => {
        const n = d.by_priority[el.dataset.prio] || 0; el.textContent = n;
        const bar = $$('[data-prio-bar]').find(b => b.dataset.prioBar === el.dataset.prio); if (bar) bar.style.width = (n / max * 100) + '%';
      });
      $('#recent').innerHTML = d.recent_html; $('#last-updated').textContent = d.updated;
      if (d.total > prev) toast((d.total - prev) + ' new ticket' + (d.total - prev > 1 ? 's' : '') + ' visible to you');
      prev = d.total;
    };
    const tick = async () => {
      if (document.hidden || !$('#live-toggle')?.checked) return;
      try { const d = await getJSON('/api/stats'); if (d) apply(d); } catch { $('#last-updated').textContent = 'offline, retrying'; }
    };
    setInterval(tick, secs * 1000);
    document.addEventListener('visibilitychange', () => { if (!document.hidden) tick(); });
  }

  /* 3. Department <-> member dropdowns stay consistent (new ticket and ticket detail). */
  $$('form').forEach(f => {
    const dep = $('select[name=department_id]', f), as = $('select[name=assignee_id]', f);
    if (!dep || !as) return;
    const all = $$('option', as).map(o => ({ v: o.value, t: o.textContent, d: o.dataset.dept || '' }));
    const fill = keep => {
      as.replaceChildren();
      all.filter(o => o.v === '' || !dep.value || o.d === dep.value).forEach(o => { const op = new Option(o.t, o.v); op.dataset.dept = o.d; as.add(op); });
      as.value = [...as.options].some(o => o.value === keep) ? keep : '';
    };
    dep.addEventListener('change', () => fill(as.value));
    as.addEventListener('change', () => {
      const d = as.selectedOptions[0]?.dataset.dept, v = as.value;
      if (d && !dep.value) { dep.value = d; fill(v); }
    });
  });

  /* 4. New-ticket form: SLA due date + customer lookup by phone. */
  const tf = $('#ticket-form');
  if (tf) {
    const prio = $('select[name=priority]', tf), due = $('input[name=due_date]', tf);
    let dueTouched = false; due.addEventListener('input', () => { dueTouched = true; });
    prio.addEventListener('change', () => { if (!dueTouched) due.value = prio.selectedOptions[0]?.dataset.due || ''; });

    const phone = $('input[name=phone]', tf), nameEl = $('input[name=customer_name]', tf);
    const hint = document.createElement('div'); hint.className = 'hint'; hint.hidden = true; phone.closest('.field').append(hint);
    let nameTouched = false; nameEl.addEventListener('input', () => { nameTouched = true; });
    let seq = 0;
    const lookup = debounce(async () => {
      const v = phone.value.trim(), mine = ++seq;
      if (!/^[+0-9 ()-]{7,30}$/.test(v)) { hint.hidden = true; return; }
      try {
        const d = await getJSON('/api/customer?phone=' + encodeURIComponent(v));
        if (mine !== seq || !d) return;
        hint.hidden = false; hint.replaceChildren();
        if (!d.found) { hint.className = 'hint'; hint.textContent = 'No previous complaints visible to you for this number.'; return; }
        if (!nameTouched || !nameEl.value) nameEl.value = d.name;
        hint.className = 'hint warn';
        const head = document.createElement('strong'); head.textContent = d.name + ' has ' + d.total + ' previous complaint' + (d.total > 1 ? 's' : '') + ':';
        hint.append(head);
        d.recent.forEach(t => {
          const row = document.createElement('div'), a = document.createElement('a');
          a.href = '/tickets/' + t.id; a.textContent = t.code; a.target = '_blank'; a.rel = 'noopener';
          row.append(a, ' · ' + t.subject + ' (' + t.status + ', ' + t.created + ')'); hint.append(row);
        });
      } catch { hint.hidden = true; }
    }, 400);
    phone.addEventListener('input', lookup);
  }

  /* 5. Small polish: no double submits, flash messages fade out. */
  $$('form[method=post]').forEach(f => f.addEventListener('submit', () => {
    const b = $('button:not([type=button])', f); if (b) setTimeout(() => { b.disabled = true; }, 0);
  }));
  addEventListener('pageshow', () => $$('form[method=post] button:disabled').forEach(b => { b.disabled = false; }));
  setTimeout(() => $$('.flash.success').forEach(f => { f.classList.add('fade'); setTimeout(() => f.remove(), 600); }), 6000);
})();
