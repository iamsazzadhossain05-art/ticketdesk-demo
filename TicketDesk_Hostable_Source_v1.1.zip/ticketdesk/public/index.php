<?php
declare(strict_types=1);
require dirname(__DIR__).'/src/views.php';
try {schema();} catch(Throwable $e) {fail(500,'Database could not be opened. Confirm PHP pdo_sqlite is enabled and storage is writable.');}
$path=parse_url($_SERVER['REQUEST_URI'],PHP_URL_PATH)?:'/';$method=$_SERVER['REQUEST_METHOD'];
if($method==='POST')check_csrf();
if($path==='/healthz'){header('Content-Type: text/plain');header('Cache-Control: no-store');echo 'ok';exit;} // reached only if the database opened and migrated
if($path==='/setup') {
    if(one('SELECT id FROM users LIMIT 1'))go('/login');
    if($method==='POST'){
        $key=trim((string)($_POST['setup_key']??''));$actual=trim((string)(getenv('TICKETDESK_SETUP_KEY')?:''));
        if(strlen($actual)<20 || !hash_equals($actual,$key)){flash('Incorrect setup key. Configure TICKETDESK_SETUP_KEY on your server first.','error');go('/setup');}
        $email=strtolower(field('email',190));$name=field('name',100);$pass=(string)($_POST['password']??'');
        if(!filter_var($email,FILTER_VALIDATE_EMAIL)||mb_strlen($name)<2||strlen($pass)<12){flash('Enter a valid email, name and password of at least 12 characters.','error');go('/setup');}
        install_defaults();run('INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)',[$name,$email,password_hash($pass,PASSWORD_DEFAULT),'admin']);
        flash('Administrator account created. You can now sign in.');go('/login');
    }
    $b=capture(function(){ echo '<h2>First-time setup</h2><p class="muted">Create your initial administrator account. The server must have a private environment variable named TICKETDESK_SETUP_KEY (minimum 20 characters).</p><form method="post">'.token();input_field('setup_key','Server setup key','','password',true);input_field('name','Admin name','', 'text',true);input_field('email','Admin email','','email',true);input_field('password','Password (12+ characters)','','password',true);echo '<button class="btn">Create administrator</button></form>';});layout('First-time setup',$b);exit;
}
if($path==='/login'){
    if(user())go('/');
    if($method==='POST'){
        $u=one('SELECT * FROM users WHERE email=? AND active=1',[strtolower(field('email',190))]);
        if(!$u || !password_verify((string)($_POST['password']??''),$u['password_hash'])){sleep(1);flash('Invalid email or password.','error');go('/login');}
        session_regenerate_id(true);$_SESSION['uid']=$u['id'];go('/');
    }
    $b=capture(function(){echo '<div class="divider"></div><h2>Sign in</h2><p class="muted">Use the account provided by your administrator.</p><form method="post">'.token();input_field('email','Email','','email',true);input_field('password','Password','','password',true);echo '<button class="btn" style="width:100%">Sign in</button></form>';});layout('Login',$b);exit;
}
if($path==='/logout' && $method==='POST'){$_SESSION=[];session_regenerate_id(true);go('/login');}
if(str_starts_with($path,'/api/')){ // JSON/HTML-fragment endpoints used by assets/app.js; always authenticated, always scoped like the pages
    $u=user();if(!$u)json_out(['error'=>'Session expired. Please sign in again.'],401);
    if($method!=='GET')json_out(['error'=>'Method not allowed.'],405);
    if($path==='/api/stats'){
        $s=dashboard_stats($u);$s['recent_html']=capture(function()use($u){ticket_table(ticket_query($u,'',[],12));});json_out($s);
    }
    if($path==='/api/customer'){
        if($u['role']==='resolver')json_out(['error'=>'Customer directory is restricted.'],403);
        $phone=trim((string)($_GET['phone']??''));$c=preg_match('/^[+0-9 ()-]{7,30}$/',$phone)?one('SELECT id,name FROM customers WHERE phone=?',[$phone]):null;
        $recent=$c?ticket_query($u,'t.customer_id=?',[$c['id']],3):[];
        if(!$c||!$recent)json_out(['found'=>false]); // an agent never learns about customers whose tickets they cannot see
        json_out(['found'=>true,'name'=>$c['name'],'total'=>ticket_total($u,'t.customer_id=?',[$c['id']]),'recent'=>array_map(fn($t)=>['id'=>(int)$t['id'],'code'=>$t['code'],'subject'=>$t['subject'],'status'=>$t['status'],'created'=>substr($t['created_at'],0,10)],$recent)]);
    }
    json_out(['error'=>'Not found.'],404);
}
if(!one('SELECT id FROM users LIMIT 1'))go('/setup');
$u=need_login();
if($path==='/' && $method==='GET'){
    $s=dashboard_stats($u);
    $b=capture(function()use($u,$s){
        titlebar('Dashboard',role_name($u['role']).' workspace · '.date('d M Y'),$u['role']==='resolver'?'':'<a class="btn" href="/tickets/new">＋ Create Ticket</a>');
        $cards=[['total','Visible Tickets','/tickets'],['open','Open','/tickets?status=Open'],['in_progress','In Progress','/tickets?status=In+Progress'],['pending','Pending','/tickets?status=Pending'],['overdue','Overdue','/tickets?overdue=1'],['due_today','Due Today','/tickets?due=today'],['unassigned','Unassigned','/tickets?assignee=none'],['resolved','Resolved','/tickets?status=Resolved']];
        echo '<div id="dash" data-total="'.(int)$s['total'].'"><div class="stats">';
        foreach($cards as [$k,$label,$href])echo '<a class="stat'.($k==='overdue'&&$s[$k]>0?' alert':'').'" href="'.h($href).'"'.($k==='overdue'?' data-stat-card="overdue"':'').'><div class="label">'.h($label).'</div><div class="value" data-stat="'.h($k).'">'.(int)$s[$k].'</div></a>';
        $names=array_unique(array_merge(option_names('priority',false),array_keys($s['by_priority'])));$max=max([1,...array_values($s['by_priority'])]);
        echo '</div><div class="grid2"><div class="card"><h2 class="section-title">Active tickets by priority</h2>';
        foreach($names as $pn){$n=$s['by_priority'][$pn]??0;echo '<div class="bar-row">'.statebadge($pn).'<div class="bar"><i data-prio-bar="'.h($pn).'" style="width:'.round($n/$max*100).'%"></i></div><strong data-prio="'.h($pn).'">'.(int)$n.'</strong></div>';}
        echo '</div><div class="card"><h2 class="section-title">Live updates</h2><p class="muted small">Counts and recent tickets refresh every '.(int)cfg('refresh_seconds',30).' seconds while this tab is visible.</p><label class="inline"><input type="checkbox" id="live-toggle" checked> Auto-refresh</label><p class="muted small">Last updated: <span id="last-updated">'.h($s['updated']).'</span></p></div></div>';
        echo '<div class="card"><div class="row"><h2 class="section-title">Recent tickets</h2><a class="btn secondary small" href="/tickets">View all</a></div><div id="recent">';ticket_table(ticket_query($u,'',[],12));echo '</div></div></div>';
    });layout('Dashboard',$b,$u);exit;
}
if($path==='/tickets' && $method==='GET'){
    [$where,$params]=filters($u);$size=(int)cfg('page_size',25);$total=ticket_total($u,$where,$params);
    $page=min(max(1,(int)ceil($total/$size)),max(1,(int)($_GET['page']??1)));$tickets=ticket_query($u,$where,$params,$size,($page-1)*$size);
    $results=capture(function()use($tickets,$total,$page,$size){
        echo '<div class="card"><div class="row"><h2 class="section-title">Tickets ('.$total.')</h2><span class="muted small">'.($total?'Showing '.(($page-1)*$size+1).'–'.min($total,$page*$size):'').'</span></div>';
        ticket_table($tickets);echo pagination($total,$page,$size,'/tickets').'</div>';
    });
    if(isset($_GET['partial'])){header('Cache-Control: no-store');echo $results;exit;} // live search / pagination fetches only this fragment
    $b=capture(function()use($results,$u){titlebar('Tickets','Search, filter and manage registered customer complaints',$u['role']==='resolver'?'':'<a href="/tickets/new" class="btn">＋ New Ticket</a>');filter_form('/tickets',true);echo '<div id="results">'.$results.'</div>';});layout('Tickets',$b,$u);exit;
}
if($path==='/tickets/new'){
    if($u['role']==='resolver')fail(403,'Only customer service staff and admins can create tickets.');
    if($method==='POST'){
        $name=field('customer_name',120);$phone=field('phone',30);$subject=field('subject',190);$desc=field('description',10000);$category=number_field('category_id');$dep=number_field('department_id');$aid=number_field('assignee_id');
        $brand=valid_choice('brand',field('brand'),'brand');$source=valid_choice('source',field('source'),'source');$priority=valid_choice('priority',field('priority'),'priority');
        if(strlen($name)<2||!preg_match('/^[+0-9 ()-]{7,30}$/',$phone)||strlen($subject)<4||strlen($desc)<4){flash('Please fill in valid required fields.','error');go('/tickets/new');}
        if($category && !one('SELECT id FROM categories WHERE id=? AND active=1',[$category]))fail(422,'Category is invalid.');
        if($dep && !one('SELECT id FROM departments WHERE id=? AND active=1',[$dep]))fail(422,'Department is invalid.');
        if($aid && !one('SELECT id FROM users WHERE id=? AND active=1 AND role="resolver"',[$aid]))fail(422,'Assignee must be an active resolution member.');
        if($aid&&!$dep)$dep=((int)(one('SELECT department_id FROM users WHERE id=?',[$aid])['department_id']??0))?:null;$due=field('due_date',10);if($due==='')$due=sla_due($priority)??'';$follow=field('followup_date',10);foreach([$due,$follow] as $d)if($d!==''&&!preg_match('/^\d{4}-\d{2}-\d{2}$/',$d))fail(422,'Invalid date.');
        db()->beginTransaction();
        try{
            $customer=one('SELECT id FROM customers WHERE phone=?',[$phone]);
            if($customer){$cid=$customer['id'];run('UPDATE customers SET name=? WHERE id=?',[$name,$cid]);}
            else {run('INSERT INTO customers(name,phone) VALUES(?,?)',[$name,$phone]);$cid=(int)db()->lastInsertId();}
            run('INSERT INTO tickets(customer_id,created_by,assignee_id,department_id,category_id,brand,source,order_id,product_sku,subject,description,priority,due_date,followup_date,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',[$cid,$u['id'],$aid,$dep,$category,$brand,$source,field('order_id',100),field('product_sku',100),$subject,$desc,$priority,$due?:null,$follow?:null,date('Y-m-d H:i:s'),date('Y-m-d H:i:s')]);
            $id=(int)db()->lastInsertId();$code='TKT-'.date('Y').'-'.str_pad((string)$id,5,'0',STR_PAD_LEFT);run('UPDATE tickets SET code=? WHERE id=?',[$code,$id]);audit($id,$u['id'],'Created','Ticket created. Priority: '.$priority);if($aid)audit($id,$u['id'],'Assigned','Assigned to selected resolution member.');
            db()->commit();flash('Ticket '.$code.' created successfully.');go('/tickets/'.$id);
        }catch(Throwable $e){db()->rollBack();throw $e;}
    }
    $categories=all('SELECT * FROM categories WHERE active=1 ORDER BY name');$depts=all('SELECT * FROM departments WHERE active=1 ORDER BY name');$staff=active_staff('resolver');
    $prioData=[];foreach(options('priority') as $pr)$prioData[$pr['name']]=['data-due'=>sla_due($pr['name'])??'','data-sla'=>(string)(int)$pr['sla_hours']];
    $defPrio=isset($prioData['Medium'])?'Medium':(string)(array_key_first($prioData)??'');$defDue=$prioData[$defPrio]['data-due']??'';
    $staffAttrs=[];foreach($staff as $sm)$staffAttrs[$sm['id']]=['data-dept'=>(string)($sm['department_id']??'')];
    $b=capture(function()use($categories,$depts,$staff,$prioData,$defPrio,$defDue,$staffAttrs){
        titlebar('Create New Ticket','Register a customer complaint and designate a responsible member');
        echo '<form method="post" class="card" id="ticket-form">'.token().'<h2 class="section-title">Customer & order information</h2><div class="form-grid">';
        input_field('customer_name','Customer name','','text',true);input_field('phone','Mobile number','','tel',true,'01XXXXXXXXX');input_field('order_id','Order ID','','text',false,'LO-51848');input_field('product_sku','Article / SKU');
        echo '<div class="field"><label>Brand</label>'.select_html('brand',option_map('brand'),option_names('brand')[0]??null).'</div><div class="field"><label>Complaint source</label>'.select_html('source',option_map('source'),option_names('source')[0]??null).'</div></div>';
        echo '<div class="divider"></div><h2 class="section-title">Complaint details</h2><div class="form-grid"><div class="field"><label>Complaint type</label>'.select_html('category_id',array_column($categories,'name','id'),null,'Select category').'</div>';input_field('subject','Ticket subject','','text',true);
        echo '</div><div class="field"><label>Description *</label><textarea name="description" required minlength="4" placeholder="Describe the complaint, order details, and requested solution..."></textarea></div>';
        echo '<div class="divider"></div><h2 class="section-title">Assignment</h2><div class="form-grid"><div class="field"><label>Priority</label>'.select_html('priority',option_map('priority'),$defPrio,'',array_map(fn($a)=>$a,$prioData)).'</div><div class="field"><label>Department</label>'.select_html('department_id',array_column($depts,'name','id'),null,'Select department').'</div><div class="field"><label>Resolution member</label>'.select_html('assignee_id',array_column($staff,'name','id'),null,'Assign later',$staffAttrs).'</div>';
        input_field('due_date','Due date',$defDue,'date');input_field('followup_date','Customer follow-up date','','date');
        echo '</div><p class="hint">Due date is pre-filled from the priority\'s SLA and updates when you change priority. Picking a member fills the department; picking a department narrows the member list.</p><div class="actions"><button class="btn">Create Ticket</button><a href="/tickets" class="btn secondary">Cancel</a></div></form>';
        echo '<div class="card"><strong>Existing customer history:</strong><p class="muted">Type a mobile number above and any previous complaints you have access to appear automatically. You can also browse the <a href="/customers">Customers</a> page.</p></div>';
    });layout('Create Ticket',$b,$u);exit;
}
if(preg_match('#^/tickets/(\d+)$#',$path,$m)){
    $id=(int)$m[1];$ticket=ticket_access($u,$id);
    if($method==='POST'){
        $action=field('action',30);
        if($action==='note'){
            $note=field('note',10000);if($note===''){flash('Enter a note before saving.','error');go($path);}
            audit($id,$u['id'],'Internal note',$note);flash('Update added to ticket.');go($path);
        }
        if($action==='status'){
            $new=valid_option(field('status'),STATUSES,'status');$old=$ticket['status'];
            if($u['role']==='resolver' && !in_array($new,['In Progress','Pending','Resolved'],true))fail(403,'Resolution members cannot close or reopen tickets.');
            if($u['role']==='agent' && !in_array($new,['Open','In Progress','Pending','Resolved','Closed'],true))fail(403,'Invalid status change.');
            if($new==='Closed' && !in_array($old,['Resolved','Closed'],true) && !is_admin($u))fail(422,'Resolve the ticket before closing it.');
            $comment=field('comment',1000);if($new==='Closed'&&$old!=='Closed'&&$comment==='')fail(422,'A closure confirmation note is required.');
            if($new!=='Closed' && $old==='Closed' && $comment==='')fail(422,'Please explain why this ticket is reopened.');
            run('UPDATE tickets SET status=?,closed_at=?,updated_at=? WHERE id=?',[$new,$new==='Closed'?date('Y-m-d H:i:s'):null,date('Y-m-d H:i:s'),$id]);
            audit($id,$u['id'],'Status changed',$old.' → '.$new.($comment!==''?' | '.$comment:''));flash('Ticket status updated.');go($path);
        }
        if($action==='assign'){
            if($u['role']==='resolver')fail(403,'Resolution members cannot reassign tickets.');
            $aid=number_field('assignee_id');$dep=number_field('department_id');$due=field('due_date',10);$follow=field('followup_date',10);
            if($aid && !one('SELECT id FROM users WHERE id=? AND active=1 AND role="resolver"',[$aid]))fail(422,'Invalid assigned member.');
            if($dep && !one('SELECT id FROM departments WHERE id=?',[$dep]))fail(422,'Invalid department.');
            foreach([$due,$follow] as $d)if($d!==''&&!preg_match('/^\d{4}-\d{2}-\d{2}$/',$d))fail(422,'Invalid date.');
            run('UPDATE tickets SET assignee_id=?,department_id=?,due_date=?,followup_date=?,updated_at=? WHERE id=?',[$aid,$dep,$due?:null,$follow?:null,date('Y-m-d H:i:s'),$id]);
            $assignee=$aid?one('SELECT name FROM users WHERE id=?',[$aid]):null;
            audit($id,$u['id'],'Assignment updated','Department: '.($dep?(one('SELECT name FROM departments WHERE id=?',[$dep])['name']??''):'None').'; Member: '.($assignee['name']??'Unassigned').'; Due: '.($due?:'None').'; Follow-up: '.($follow?:'None'));
            flash('Assignment and schedule updated.');go($path);
        }
        if($action==='edit'){
            if($u['role']==='resolver')fail(403,'Resolution members cannot edit complaint details.');
            $subject=field('subject',190);$desc=field('description',10000);$resolution=field('resolution',5000);$priority=valid_choice('priority',field('priority'),'priority',$ticket['priority']);
            if(strlen($subject)<4||strlen($desc)<4)fail(422,'Subject and description are required.');
            run('UPDATE tickets SET subject=?,description=?,resolution=?,priority=?,updated_at=? WHERE id=?',[$subject,$desc,$resolution,$priority,date('Y-m-d H:i:s'),$id]);
            audit($id,$u['id'],'Ticket details edited','Subject: '.$subject.'; Priority: '.$ticket['priority'].' → '.$priority.'. '.(trim($resolution)!==''?'Resolution summary updated.':''));flash('Ticket details updated.');go($path);
        }
        if($action==='adminedit'){
            admin($u);
            $name=field('customer_name',120);$phone=field('phone',30);$brand=valid_choice('brand',field('brand'),'brand',$ticket['brand']);$source=valid_choice('source',field('source'),'source',$ticket['source']);
            $cat=number_field('category_id');
            if(strlen($name)<2 || !preg_match('/^[+0-9 ()-]{7,30}$/',$phone))fail(422,'Invalid customer details.');
            if($cat&&$cat!==(int)$ticket['category_id']&&!one('SELECT id FROM categories WHERE id=? AND active=1',[$cat]))fail(422,'Invalid complaint category.');
            // Customer profiles are keyed by phone; changing a ticket's customer links to the correct profile.
            $existing=one('SELECT id FROM customers WHERE phone=?',[$phone]);
            db()->beginTransaction();
            try {
                if($existing){$cid=(int)$existing['id'];run('UPDATE customers SET name=? WHERE id=?',[$name,$cid]);}
                elseif($phone===$ticket['customer_phone']){$cid=(int)$ticket['customer_id'];run('UPDATE customers SET name=? WHERE id=?',[$name,$cid]);}
                else {run('INSERT INTO customers(name,phone) VALUES(?,?)',[$name,$phone]);$cid=(int)db()->lastInsertId();}
                run('UPDATE tickets SET customer_id=?,brand=?,source=?,order_id=?,product_sku=?,category_id=?,updated_at=? WHERE id=?',[$cid,$brand,$source,field('order_id',100),field('product_sku',100),$cat,date('Y-m-d H:i:s'),$id]);
                audit($id,$u['id'],'Admin corrected customer/order details','Old customer: '.$ticket['customer_name'].' ('.$ticket['customer_phone'].'); old order: '.$ticket['order_id'].'; New customer: '.$name.' ('.$phone.'); new order: '.field('order_id',100));
                db()->commit();
            } catch(Throwable $e){db()->rollBack();throw $e;}
            flash('Customer and order data updated.');go($path);
        }
        if($action==='upload'){
            if(!isset($_FILES['file']) || $_FILES['file']['error']!==UPLOAD_ERR_OK)fail(422,'File upload failed.');
            $file=$_FILES['file'];global $config;
            if((int)$file['size']>$config['max_upload_bytes'] || (int)$file['size']<=0)fail(422,'File must be smaller than 5 MB.');
            $mime=(new finfo(FILEINFO_MIME_TYPE))->file($file['tmp_name']);$allowed=['image/jpeg'=>'jpg','image/png'=>'png','application/pdf'=>'pdf'];
            if(!isset($allowed[$mime]))fail(422,'Only JPG, PNG and PDF files are permitted.');
            $orig=basename((string)$file['name']);$orig=mb_substr($orig,0,160);$new=bin2hex(random_bytes(20)).'.'.$allowed[$mime];
            if(!is_dir($config['upload_path']))mkdir($config['upload_path'],0700,true);
            if(!move_uploaded_file($file['tmp_name'],$config['upload_path'].'/'.$new))fail(500,'Could not store the attachment.');
            run('INSERT INTO attachments(ticket_id,user_id,original_name,stored_name,mime,size) VALUES(?,?,?,?,?,?)',[$id,$u['id'],$orig,$new,$mime,(int)$file['size']]);
            audit($id,$u['id'],'File attached','Uploaded '. $orig);flash('Attachment uploaded.');go($path);
        }
        fail(400,'Unknown ticket action.');
    }
    $activities=all('SELECT a.*,u.name user_name FROM activities a JOIN users u ON u.id=a.user_id WHERE a.ticket_id=? ORDER BY a.created_at DESC,a.id DESC',[$id]);
    $attachments=all('SELECT * FROM attachments WHERE ticket_id=? ORDER BY id DESC',[$id]);
    $staff=active_staff('resolver');$depts=all('SELECT * FROM departments WHERE active=1 OR id=? ORDER BY name',[(int)$ticket['department_id']]);$staffAttrs=[];foreach($staff as $sm)$staffAttrs[$sm['id']]=['data-dept'=>(string)($sm['department_id']??'')];
    $b=capture(function()use($ticket,$u,$activities,$attachments,$staff,$depts,$path,$staffAttrs){
        titlebar($ticket['code'],$ticket['subject'],'<a href="/tickets" class="btn secondary">All Tickets</a>');
        echo '<div class="row" style="margin-bottom:18px"><div class="actions">'.statebadge($ticket['status']).' '.statebadge($ticket['priority']).' <span class="pill">'.h($ticket['brand']).'</span></div><span class="muted small">Created '.h($ticket['created_at']).'</span></div>';
        if($ticket['due_date'] && $ticket['due_date']<date('Y-m-d') && !in_array($ticket['status'],['Resolved','Closed']))echo '<div class="notice">This ticket is overdue. Target date: '.h($ticket['due_date']).'</div>';
        echo '<div class="detail-grid"><div><div class="card"><h2 class="section-title">Complaint details</h2><dl>';
        foreach(['Customer'=>$ticket['customer_name'],'Phone'=>$ticket['customer_phone'],'Order ID'=>$ticket['order_id'],'Article / SKU'=>$ticket['product_sku'],'Complaint type'=>$ticket['category_name'],'Source'=>$ticket['source'],'Department'=>$ticket['department_name'],'Assigned member'=>$ticket['assignee_name'],'Created by'=>$ticket['creator_name'],'Due date'=>$ticket['due_date'],'Follow-up date'=>$ticket['followup_date'],'Closed at'=>$ticket['closed_at']] as $k=>$v)echo '<div class="kv"><dt>'.h($k).'</dt><dd>'.h($v?:'—').'</dd></div>';
        echo '</dl><h3>Complaint description</h3><p style="white-space:pre-wrap">'.h($ticket['description']).'</p>';
        if($ticket['resolution'])echo '<h3>Resolution summary</h3><p style="white-space:pre-wrap">'.h($ticket['resolution']).'</p>';
        echo '</div><div class="card"><h2 class="section-title">Date-wise activity timeline</h2><div class="timeline">';
        foreach($activities as $a)echo '<div class="event"><div class="meta">'.h($a['created_at']).' · '.h($a['user_name']).'</div><div class="event-name">'.h($a['action']).'</div><div class="detail">'.h($a['details']).'</div></div>';
        echo '</div><div class="divider"></div><h3>Add an internal update</h3><form method="post">'.token().'<input type="hidden" name="action" value="note"><div class="field"><label>Progress note</label><textarea name="note" required placeholder="Investigation update, courier response, customer feedback..."></textarea></div><button class="btn">Post Update</button></form></div>';
        echo '<div class="card"><h2 class="section-title">Attachments</h2>';
        if(!$attachments)echo '<p class="muted">No attachments yet.</p>';
        foreach($attachments as $a)echo '<p><a href="/attachment/'.(int)$a['id'].'">'.h($a['original_name']).'</a> <span class="muted small">('.round($a['size']/1024).' KB)</span></p>';
        echo '<form method="post" enctype="multipart/form-data">'.token().'<input type="hidden" name="action" value="upload"><div class="field"><label>Upload evidence (JPG, PNG or PDF, 5 MB max)</label><input class="input" type="file" name="file" accept="image/jpeg,image/png,application/pdf" required></div><button class="btn secondary">Upload file</button></form></div></div><div>';
        echo '<div class="card"><h2 class="section-title">Update status</h2><form method="post">'.token().'<input type="hidden" name="action" value="status"><div class="field"><label>Status</label>';
        $statuses=$u['role']==='resolver'?['In Progress'=>'In Progress','Pending'=>'Pending','Resolved'=>'Resolved']:['Open'=>'Open','In Progress'=>'In Progress','Pending'=>'Pending','Resolved'=>'Resolved','Closed'=>'Closed'];echo select_html('status',$statuses,$ticket['status']).'</div><div class="field"><label>Note (required for close/reopen)</label><textarea name="comment" style="min-height:76px" placeholder="Resolution confirmation or reason for reopening"></textarea></div><button class="btn">Save Status</button></form></div>';
        if($u['role']!=='resolver'){
            echo '<div class="card"><h2 class="section-title">Assignment & deadlines</h2><form method="post">'.token().'<input type="hidden" name="action" value="assign"><div class="field"><label>Department</label>'.select_html('department_id',array_column($depts,'name','id'),$ticket['department_id'],'Not assigned').'</div><div class="field"><label>Responsible member</label>'.select_html('assignee_id',array_column($staff,'name','id'),$ticket['assignee_id'],'Unassigned',$staffAttrs).'</div>';input_field('due_date','Due date',$ticket['due_date']??'','date');input_field('followup_date','Follow-up date',$ticket['followup_date']??'','date');echo '<button class="btn">Update Assignment</button></form></div>';
            echo '<div class="card"><h2 class="section-title">Edit ticket details</h2><form method="post">'.token().'<input type="hidden" name="action" value="edit">';input_field('subject','Subject',$ticket['subject'],'text',true);echo '<div class="field"><label>Priority</label>'.select_html('priority',option_map('priority',$ticket['priority']),$ticket['priority']).'</div><div class="field"><label>Description</label><textarea name="description" required>'.h($ticket['description']).'</textarea></div><div class="field"><label>Resolution summary</label><textarea name="resolution">'.h($ticket['resolution']).'</textarea></div><button class="btn secondary">Save Details</button></form></div>';
        }
        if(is_admin($u)){
            $cats=all('SELECT * FROM categories WHERE active=1 OR id=? ORDER BY name',[(int)$ticket['category_id']]);
            echo '<div class="card"><h2 class="section-title">Admin: customer & order correction</h2><form method="post">'.token().'<input type="hidden" name="action" value="adminedit">';
            input_field('customer_name','Customer name',$ticket['customer_name'],'text',true);
            input_field('phone','Customer mobile',$ticket['customer_phone'],'tel',true);
            input_field('order_id','Order ID',$ticket['order_id']);
            input_field('product_sku','Article / SKU',$ticket['product_sku']);
            echo '<div class="field"><label>Brand</label>'.select_html('brand',option_map('brand',$ticket['brand']),$ticket['brand']).'</div>';
            echo '<div class="field"><label>Source</label>'.select_html('source',option_map('source',$ticket['source']),$ticket['source']).'</div>';
            echo '<div class="field"><label>Complaint category</label>'.select_html('category_id',array_column($cats,'name','id'),$ticket['category_id'],'Uncategorized').'</div>';
            echo '<button class="btn secondary">Save Corrections</button></form></div>';
        }
        echo '</div></div>';
    });layout($ticket['code'],$b,$u);exit;
}
if(preg_match('#^/attachment/(\d+)$#',$path,$m) && $method==='GET'){
    $a=one('SELECT * FROM attachments WHERE id=?',[(int)$m[1]]);if(!$a)fail(404,'Attachment not found.');ticket_access($u,(int)$a['ticket_id']);global $config;
    $file=$config['upload_path'].'/'.$a['stored_name'];if(!is_file($file))fail(404,'Stored attachment not found.');
    header('Content-Type: '.$a['mime']);header('Content-Length: '.filesize($file));header('Content-Disposition: attachment; filename="'.str_replace(['"',"\r","\n"],'_', $a['original_name']).'"');header('Cache-Control: private, no-store');readfile($file);exit;
}
if($path==='/customers' && $method==='GET'){
    if($u['role']==='resolver')fail(403,'Customer directory is restricted.');
    $q=trim((string)($_GET['q']??''));
    $customers=all('SELECT c.*,COUNT(t.id) ticket_count FROM customers c JOIN tickets t ON t.customer_id=c.id '.($u['role']==='agent'?'AND t.created_by=? ':'').'WHERE (c.phone LIKE ? OR c.name LIKE ?) GROUP BY c.id ORDER BY c.id DESC LIMIT 200',$u['role']==='agent'?[$u['id'],'%'.$q.'%','%'.$q.'%']:['%'.$q.'%','%'.$q.'%']);
    $b=capture(function()use($customers,$q){titlebar('Customers','Search existing customers and review complaint history');echo '<form class="card filterbar" method="get"><div class="field wide"><label>Mobile number or name</label><input class="input" name="q" value="'.h($q).'" placeholder="Search customer"></div><button class="btn">Search</button></form><div class="card"><div class="table-wrap"><table><thead><tr><th>Customer</th><th>Mobile</th><th>Tickets</th><th>History</th></tr></thead><tbody>';foreach($customers as $c)echo '<tr><td>'.h($c['name']).'</td><td>'.h($c['phone']).'</td><td>'.(int)$c['ticket_count'].'</td><td><a href="/customers/'.(int)$c['id'].'">View history</a></td></tr>';echo '</tbody></table></div></div>';});layout('Customers',$b,$u);exit;
}
if(preg_match('#^/customers/(\d+)$#',$path,$m) && $method==='GET'){
    if($u['role']==='resolver')fail(403,'Customer directory is restricted.');
    $c=one('SELECT * FROM customers WHERE id=?',[(int)$m[1]]);if(!$c)fail(404,'Customer not found.');$tickets=ticket_query($u,'t.customer_id=?',[$c['id']],100);
    if(!$tickets)fail(403,'No accessible tickets for this customer.');
    $b=capture(function()use($c,$tickets){titlebar($c['name'],'Customer mobile: '.$c['phone']);echo '<div class="card"><h2 class="section-title">Complaint history</h2>';ticket_table($tickets);echo '</div>';});layout('Customer History',$b,$u);exit;
}
if($path==='/reports' && $method==='GET'){
    [$where,$params]=filters($u);$tickets=ticket_query($u,$where,$params,10000);
    $status=[];$category=[];$brand=[];$agent=[];$prio=[];$hours=[];
    foreach($tickets as $t){$prio[$t['priority']]=($prio[$t['priority']]??0)+1;if($t['closed_at'])$hours[]=(strtotime($t['closed_at'])-strtotime($t['created_at']))/3600;$status[$t['status']]=($status[$t['status']]??0)+1;$category[$t['category_name']??'Other']=($category[$t['category_name']??'Other']??0)+1;$brand[$t['brand']]=($brand[$t['brand']]??0)+1;$agent[$t['assignee_name']??'Unassigned']=($agent[$t['assignee_name']??'Unassigned']??0)+1;}
    if(isset($_GET['export'])&&$_GET['export']==='csv'){
        header('Content-Type: text/csv; charset=utf-8');header('Content-Disposition: attachment; filename="ticket-report-'.date('Ymd').'.csv"');header('Cache-Control: private, no-store');
        $f=fopen('php://output','w');fwrite($f,"\xEF\xBB\xBF");fputcsv($f,['Ticket ID','Created','Customer','Phone','Brand','Order ID','Category','Subject','Status','Priority','Assignee','Due Date','Closed At']);
        foreach($tickets as $t){$values=[$t['code'],$t['created_at'],$t['customer_name'],$t['customer_phone'],$t['brand'],$t['order_id'],$t['category_name'],$t['subject'],$t['status'],$t['priority'],$t['assignee_name'],$t['due_date'],$t['closed_at']];$values=array_map(fn($v)=>preg_match('/^[=+\-@\t\r]/',(string)$v)?"'".$v:$v,$values);fputcsv($f,$values);}fclose($f);exit;
    }
    $b=capture(function()use($tickets,$status,$category,$brand,$agent,$prio,$hours){titlebar('Reports','Ticket performance, complaint trends and downloadable records');filter_form('/reports');echo '<div class="row" style="margin-bottom:18px"><strong>'.count($tickets).' matching tickets</strong><span class="muted small">'.($hours?'Avg. time to close: '.round(array_sum($hours)/count($hours),1).' h':'').'</span><a class="btn" href="/reports?'.h(http_build_query(array_merge($_GET,['export'=>'csv']))).'">↓ Export CSV</a></div><div class="grid2">';foreach(['Ticket status'=>$status,'Complaint categories'=>$category,'Brand distribution'=>$brand,'Resolution members'=>$agent,'Priority'=>$prio] as $title=>$data){arsort($data);echo '<div class="card"><h2 class="section-title">'.h($title).'</h2><table><tbody>';foreach($data as $name=>$count)echo '<tr><td>'.h($name).'</td><td style="text-align:right"><strong>'.(int)$count.'</strong></td></tr>';if(!$data)echo '<tr><td class="muted">No data for selected filters</td></tr>';echo '</tbody></table></div>';}echo '</div>';});layout('Reports',$b,$u);exit;
}
if($path==='/users'){
    admin($u);
    if($method==='POST'){
        $action=field('action',20);
        if($action==='create'){
            $name=field('name',100);$email=strtolower(field('email',190));$password=(string)($_POST['password']??'');$role=valid_option(field('role'),['admin','agent','resolver'],'role');$dep=number_field('department_id');
            if(mb_strlen($name)<2||!filter_var($email,FILTER_VALIDATE_EMAIL)||strlen($password)<12){flash('Provide a valid name, email and password (12 characters minimum).','error');go('/users');}
            if(one('SELECT id FROM users WHERE email=?',[$email])){flash('Email address already exists.','error');go('/users');}
            if($dep&&!one('SELECT id FROM departments WHERE id=?',[$dep]))fail(422,'Invalid department.');
            run('INSERT INTO users(name,email,password_hash,role,department_id) VALUES(?,?,?,?,?)',[$name,$email,password_hash($password,PASSWORD_DEFAULT),$role,$dep]);flash('Team member created.');go('/users');
        }
        if($action==='update'){
            $id=number_field('user_id');$role=valid_option(field('role'),['admin','agent','resolver'],'role');$dep=number_field('department_id');
            if(!$id||!one('SELECT id FROM users WHERE id=?',[$id]))fail(404,'User not found.');
            if($id===(int)$u['id']&&$role!=='admin')fail(422,'You cannot remove your own administrator role.');
            if($dep&&!one('SELECT id FROM departments WHERE id=?',[$dep]))fail(422,'Invalid department.');
            run('UPDATE users SET role=?,department_id=? WHERE id=?',[$role,$dep,$id]);flash('Role and department updated.');go('/users');
        }
        if($action==='toggle'){
            $id=number_field('user_id');if(!$id||$id===$u['id'])fail(422,'You cannot deactivate yourself.');
            $target=one('SELECT id,active FROM users WHERE id=?',[$id]);if(!$target)fail(404,'User not found.');
            run('UPDATE users SET active=? WHERE id=?',[$target['active']?0:1,$id]);flash('User account status updated.');go('/users');
        }
        if($action==='reset'){
            $id=number_field('user_id');$password=(string)($_POST['password']??'');if(!$id||strlen($password)<12)fail(422,'Password requires at least 12 characters.');
            run('UPDATE users SET password_hash=? WHERE id=?',[password_hash($password,PASSWORD_DEFAULT),$id]);flash('Password reset.');go('/users');
        }
        fail(400,'Unknown user action.');
    }
    $users=all('SELECT u.*,d.name department FROM users u LEFT JOIN departments d ON d.id=u.department_id ORDER BY u.active DESC,u.name');$depts=all('SELECT * FROM departments ORDER BY name');
    $b=capture(function()use($users,$depts){titlebar('Team Management','Administrator: manage staff accounts and permissions');echo '<div class="grid2"><div class="card"><h2 class="section-title">Add team member</h2><form method="post">'.token().'<input type="hidden" name="action" value="create">';input_field('name','Full name','','text',true);input_field('email','Work email','','email',true);input_field('password','Temporary password (12+ characters)','','password',true);echo '<div class="field"><label>Role</label>'.select_html('role',['agent'=>'Customer Service Agent','resolver'=>'Issue Resolution','admin'=>'Administrator'],'agent').'</div><div class="field"><label>Department</label>'.select_html('department_id',array_column($depts,'name','id'),null,'No department').'</div><button class="btn">Create Member</button></form></div><div class="card"><h2 class="section-title">Access overview</h2><p><strong>Admin:</strong> all records, settings and staff management.</p><p><strong>Customer Service:</strong> own complaints, customer follow-ups and assignment.</p><p><strong>Issue Resolution:</strong> assigned and department tickets, progress updates and resolution.</p><div class="notice">Give each employee a unique login. Never share passwords.</div></div></div><div class="card"><h2 class="section-title">Staff directory</h2><div class="table-wrap"><table><thead><tr><th>Employee</th><th>Role</th><th>Department</th><th>Status</th><th>Actions</th></tr></thead><tbody>';foreach($users as $m){echo '<tr><td><strong>'.h($m['name']).'</strong><br><span class="muted small">'.h($m['email']).'</span></td><td>'.h(role_name($m['role'])).'</td><td>'.h($m['department']??'—').'</td><td>'.($m['active']?'<span class="badge Resolved">Active</span>':'<span class="badge">Inactive</span>').'</td><td><div class="actions"><form method="post" class="actions">'.token().'<input type="hidden" name="action" value="update"><input type="hidden" name="user_id" value="'.(int)$m['id'].'">'.select_html('role',['agent'=>'Customer Service','resolver'=>'Issue Resolution','admin'=>'Administrator'],$m['role']).select_html('department_id',array_column($depts,'name','id'),$m['department_id'],'No dept').'<button class="btn small secondary">Save</button></form><form method="post">'.token().'<input type="hidden" name="action" value="toggle"><input type="hidden" name="user_id" value="'.(int)$m['id'].'"><button class="btn small secondary">'.($m['active']?'Deactivate':'Activate').'</button></form><form method="post" class="actions">'.token().'<input type="hidden" name="action" value="reset"><input type="hidden" name="user_id" value="'.(int)$m['id'].'"><input class="input" style="width:150px;padding:7px" name="password" type="password" minlength="12" required placeholder="New password"><button class="btn small secondary">Reset</button></form></div></td></tr>';}echo '</tbody></table></div></div>';});layout('Team Management',$b,$u);exit;
}
if($path==='/settings'){
    admin($u);
    // Every list below is data, not code: forms, filters and validation read them at request time.
    $kinds=['department'=>['Departments','departments'],'category'=>['Complaint categories','categories'],'brand'=>['Brands','options'],'source'=>['Complaint sources','options'],'priority'=>['Priorities & default SLA','options']];
    if($method==='POST'){
        $kind=valid_option(field('kind'),array_keys($kinds),'setting');$act=field('act',10)?:'add';$table=$kinds[$kind][1];$typed=$table==='options';
        $hours=max(0,min(8760,number_field('sla_hours')??0));
        if($act==='add'){
            $name=field('name',90);if(mb_strlen($name)<2)fail(422,'Name must be at least two characters.');
            try{
                if($typed){$next=(int)one('SELECT COALESCE(MAX(sort_order),0)+10 n FROM options WHERE type=?',[$kind])['n'];run('INSERT INTO options(type,name,sort_order,sla_hours) VALUES(?,?,?,?)',[$kind,$name,$next,$kind==='priority'?$hours:0]);}
                else run('INSERT INTO '.$table.'(name) VALUES(?)',[$name]);
                flash(ucfirst($kind).' added.');
            }catch(PDOException $e){flash('That name already exists.','error');}
        }elseif($act==='toggle'||($act==='sla'&&$kind==='priority')){
            $id=number_field('id');$row=$id?one('SELECT * FROM '.$table.' WHERE id=?'.($typed?' AND type=?':''),$typed?[$id,$kind]:[$id]):null;if(!$row)fail(404,'Item not found.');
            if($act==='sla'){run('UPDATE options SET sla_hours=? WHERE id=?',[$hours,$id]);flash('SLA updated.');}
            else{
                if($typed&&$row['active']&&(int)one('SELECT COUNT(*) n FROM options WHERE type=? AND active=1 AND id<>?',[$kind,$id])['n']<1){flash('At least one active '.$kind.' is required.','error');go('/settings');}
                run('UPDATE '.$table.' SET active=? WHERE id=?',[$row['active']?0:1,$id]);flash(ucfirst($kind).($row['active']?' disabled. Existing tickets keep their value.':' enabled.'));
            }
        }else fail(400,'Unknown settings action.');
        go('/settings');
    }
    $lists=[];foreach($kinds as $k=>[$t,$tbl])$lists[$k]=$tbl==='options'?all('SELECT * FROM options WHERE type=? ORDER BY sort_order,id',[$k]):all('SELECT * FROM '.$tbl.' ORDER BY name');
    $b=capture(function()use($kinds,$lists){
        titlebar('Settings','Manage the lists that drive ticket forms, filters, validation and SLA targets');
        echo '<div class="grid2">';
        foreach($kinds as $kind=>[$title]){
            echo '<div class="card"><h2 class="section-title">'.h($title).'</h2>';
            foreach($lists[$kind] as $i){
                $hid='<input type="hidden" name="kind" value="'.h($kind).'"><input type="hidden" name="id" value="'.(int)$i['id'].'">';
                echo '<div class="setting-row'.($i['active']?'':' off').'"><span>'.h($i['name']).'</span><div class="actions">';
                if($kind==='priority')echo '<form method="post" class="actions">'.token().$hid.'<input type="hidden" name="act" value="sla"><input class="input" style="width:72px;padding:6px" name="sla_hours" type="number" min="0" max="8760" value="'.(int)$i['sla_hours'].'" title="Default due time in hours (0 = no default)"><span class="muted small">hrs</span><button class="btn small secondary">Save</button></form>';
                echo '<form method="post">'.token().$hid.'<input type="hidden" name="act" value="toggle"><button class="btn small secondary">'.($i['active']?'Disable':'Enable').'</button></form></div></div>';
            }
            echo '<form method="post" class="add-form">'.token().'<input type="hidden" name="kind" value="'.h($kind).'"><div class="field"><label>Add new '.h($kind).'</label><input class="input" name="name" required placeholder="New name"></div>'.($kind==='priority'?'<div class="field"><label>Default SLA (hours, 0 = none)</label><input class="input" name="sla_hours" type="number" min="0" max="8760" value="48"></div>':'').'<button class="btn">Add '.h(ucfirst($kind)).'</button></form></div>';
        }
        echo '</div>';
    });layout('Settings',$b,$u);exit;
}
fail(404,'Page not found.');
