# TicketDesk — Multi-Agent Customer Complaint System (v1.1)

An internal, browser-based ticket system with three roles, assigned resolution work, dated notes, file attachments, customer complaint history and CSV reports. **No third-party API integration is required.**

## Features

- **Administrator** — sees every ticket, creates/activates/deactivates users, adds departments/categories, resets passwords, edits and closes tickets, views reports.
- **Customer Service Agent** — creates tickets, sees their own tickets and customer history, sets priorities, assigns resolution members, updates notes, verifies and closes resolved tickets.
- **Issue Resolution Member** — sees tickets assigned to themselves or their department, adds updates, uploads evidence, changes status to In Progress / Pending / Resolved.
- Tickets contain brand (LottoBD / LeeCooperBD / Other), phone, name, order ID, SKU, complaint category, source, priority, due date, follow-up date, assigned department/person, and description.
- An append-only activity timeline records who did what and when. History is preserved upon reopening.
- Ticket search, brand/status/date filtering, overdue indicators, complaint reports and Excel-compatible CSV export.
- Protected PDF/JPG/PNG attachments (5 MB maximum).

## What's dynamic in v1.1

**Data-driven, not hardcoded.** Brands, complaint sources, priorities, departments and categories are managed by the administrator under **Settings** and take effect immediately in forms, filters and validation. Disabling an item hides it from new tickets but never breaks existing ones (a ticket keeps its original value and stays filterable). At least one brand/source/priority must remain active.

**Priority-based SLA.** Each priority has a default due time in hours (defaults: Low 72, Medium 48, High 24, Urgent 8; set `0` for none). New tickets get a due date from their priority automatically, and the form updates it live when priority changes (a date typed by hand is never overwritten).

**Live interface** (plain JavaScript, no build step; every page still works without it):
- Ticket list: search-as-you-type, instant filters, in-place pagination, shareable URLs.
- Dashboard: self-refreshing counters, priority breakdown, recent tickets; pauses when the tab is hidden. Cards link to pre-filtered lists (Overdue, Due today, Unassigned, ...).
- New ticket: typing a mobile number shows previous complaints and fills the name. It respects the same visibility rules as the Customers page, so an agent never learns about customers they have no tickets for.
- Department and responsible-member dropdowns narrow each other; choosing a member fills the department.

**Runtime configuration.** All settings can be set with environment variables (see the table below), so one build serves several deployments.

**Admin additions.** Change a user's role/department after creation; reports include priority breakdown and average time to close; `/healthz` endpoint for uptime checks; idle-session timeout.

### Configuration (environment variables; all optional)

| Variable | Default | Purpose |
|---|---|---|
| `TICKETDESK_SETUP_KEY` | *(required for setup)* | Authorises first admin creation (20+ chars) |
| `TICKETDESK_APP_NAME` | `TicketDesk` | Name in title, logo and footer |
| `TICKETDESK_TIMEZONE` | `Asia/Dhaka` | PHP timezone for timestamps and due dates |
| `TICKETDESK_MAX_UPLOAD_MB` | `5` | Attachment limit (Docker also derives PHP limits from it) |
| `TICKETDESK_PAGE_SIZE` | `25` | Tickets per page (5-200) |
| `TICKETDESK_REFRESH_SECONDS` | `30` | Dashboard auto-refresh interval (10-600) |
| `TICKETDESK_IDLE_MINUTES` | `120` | Idle session timeout, `0` = never |
| `TICKETDESK_DB_PATH` / `TICKETDESK_UPLOAD_PATH` | `storage/...` | Override storage locations |

### Upgrading from v1.0

Replace the code and keep `storage/`. On the first request the app migrates the database automatically in one transaction (adds an `options` table seeded with the old hardcoded values, adds `departments.active`, adds indexes). No existing ticket, user or attachment is modified. **Back up `storage/` first**, as always. Note that new tickets now receive a default due date from the priority SLA; set a priority's SLA to `0` in Settings to opt out.

## Hosting requirements

- PHP **8.2+** with `pdo_sqlite`, `sqlite3`, `fileinfo`, `mbstring`, `openssl`, `session` enabled.
- Apache with mod_rewrite (or Nginx configured to route non-static paths to `public/index.php`).
- Writable private `storage/` directory, and HTTPS with a valid certificate.
- **Set your website's document root to the `public/` directory.** Do not point it to the project root.

## Install on a VPS / PHP hosting account

1. Upload this entire `ticketdesk/` folder to the server, e.g. `/var/www/ticketdesk/`.
2. Set the domain or subdomain (e.g. `support.example.com`) **document root** to `/var/www/ticketdesk/public`.
3. Set ownership/permissions so PHP can write in `storage/` but the web server cannot browse it.
4. Create a **private server environment variable** `TICKETDESK_SETUP_KEY` with a random string at least 20 characters long, e.g. `openssl rand -hex 32`. The value is used only to authorize initial admin account creation. In Apache/PHP-FPM configure the variable in your server pool configuration or host's environment settings. Do not place it in public/.
5. Visit `https://support.example.com/setup` and enter the same setup key, an admin name, email, and a password at least 12 characters long.
6. Go to `/login`. Admin can create all other user accounts at **Team Management**.
7. After installing, remove `TICKETDESK_SETUP_KEY` from the environment. The setup page automatically redirects to login once the first user exists.
8. Configure a **daily backup** of `storage/` (database and uploads) to a separate protected location. SQLite database backups must be consistent: use SQLite online backup API or stop writes before copying; do not copy only a WAL-mode database file while active.

## Local development

```bash
php -S 127.0.0.1:8000 -t public public/index-router.php
```

Then visit http://127.0.0.1:8000/setup and set `TICKETDESK_SETUP_KEY` in the environment before starting the PHP server.

Example on Linux/macOS:

```bash
export TICKETDESK_SETUP_KEY="$(openssl rand -hex 32)"
php -S 127.0.0.1:8000 -t public public/index-router.php
```

## Data model

- `users`: role, department, active status and securely hashed passwords.
- `departments`: functional support teams.
- `categories`: admin-managed complaint types.
- `customers`: unique phone number and customer name.
- `tickets`: order, complaint, brand, assignment, status, due date and resolution.
- `activities`: append-only dated audit trail of ticket actions and notes.
- `attachments`: private file references and ownership.

The database and default complaint categories are created automatically on first request. A fresh installation contains **no demo data**.

## Operational and security notes

- This is a functional **Version 1 MVP**, not a completed enterprise helpdesk. Before public business rollout, use a security review, staging test, and load test; set up monitoring, backups, and recovery drills.
- Use an internal-only subdomain or VPN/access restriction when practical. Always enable HTTPS.
- Sessions use HttpOnly + SameSite cookies; Secure cookies automatically apply on HTTPS. Forms include CSRF tokens, queries use prepared SQL statements and passwords are hashed.
- Attachments are stored outside the public document root and authenticated before download.
- The first administrator can change records through the UI but cannot edit or delete previous activity records through the UI.
- Customer service staff are intentionally scoped to tickets they created. Issue resolution staff are scoped to assigned tickets and their department's tickets. Admin sees all tickets.
- The ticket list is paginated (`TICKETDESK_PAGE_SIZE`) and the dashboard aggregates in SQL. The report page and CSV export still load up to 10,000 matching tickets; add narrower filters or streamed export for very large datasets.
- For very high volume/concurrent writes, migrate SQLite to PostgreSQL or MySQL. For a small internal team, SQLite is an easy starting point.
- Potential future improvements: login rate limiting, password reset with email, two-factor login, customer profile editing with audit, ticket merge, live notifications, SLA calculation with office hours, notifications, automated assignment and bulk operations.
- No customer SMS/email/WhatsApp messages are automatically sent. Communication and order updates remain manual, as requested.

## Nginx example

```nginx
server {
  listen 443 ssl;
  server_name support.example.com;
  root /var/www/ticketdesk/public;
  index index.php;
  # Configure ssl_certificate and ssl_certificate_key appropriately.
  location / { try_files $uri $uri/ /index.php?$query_string; }
  location ~ \.php$ {
    include fastcgi_params;
    fastcgi_param SCRIPT_FILENAME $document_root$fastcgi_script_name;
    fastcgi_pass unix:/run/php/php8.2-fpm.sock; # adjust to your installation
  }
  location ~ /\. { deny all; }
}
```

## Important

**Do not expose the project root** or `storage/` to the internet. The domain must serve files only from `public/`.

## Docker deployment (recommended for a VPS)

Install Docker and Docker Compose on a Linux server. From the project directory:

```bash
printf 'TICKETDESK_SETUP_KEY=%s\n' "$(openssl rand -hex 32)" > .env
chmod 600 .env
docker compose up -d --build
```

The web app will listen on **127.0.0.1:8080**. Put a reverse proxy such as Caddy or Nginx in front of this port, with automatic TLS / HTTPS. Visit `https://your-subdomain/setup`, enter the key in `.env`, and create your admin. **Do not directly expose port 8080 to the internet.**

The container exposes a health check (`/healthz`), derives PHP upload limits from `TICKETDESK_MAX_UPLOAD_MB`, and reads the optional variables above from `.env` (see `.env.example`). The `ticketdesk_storage` Docker volume persists database and uploaded files across container recreation. Back up that volume regularly. Rotate/remove the setup environment variable after setup if desired (requires updating Compose configuration).
